var draw = document.getElementById("parent");
var context = draw.getContext("2d");
var width = draw.width = window.innerHeight;
var height = draw.height =  window.innerHeight;
var mouseClicked = false;
var mouseReleased= true;
document.addEventListener ("click",onMouseClick,false);
document.addEventListener ("mousemove",onMouseMove,false);
function onMouseClick(e){
	mouseClicked=!mouseClicked;
}
function getRandomColour(){
var letters="0123456789ABCDEF";
var color = "#";
for (var i = 0;i <6;i++){
color=color+=letters[Math.floor(Math.random()*16)];
} return color;}
function onMouseMove(e){
	if(mouseClicked){
	context.beginPath();
	context.arc(event.clientX,event.clientY,7.5, Math.PI*2,false);
	context.lineWidth=10;
	context.strokeStyle = getRandomColour();
	context.stroke();	
	}  }
function clear(){
	context.clearRect(0,0,canvas.width,draw.height);
}





